1.nginx进程
[root@hwy_pf_01 lua]# nginx -V
nginx version: nginx/1.9.7
built by gcc 4.4.7 20120313 (Red Hat 4.4.7-18) (GCC) 
built with OpenSSL 1.0.1e-fips 11 Feb 2013
TLS SNI support enabled
configure arguments: --prefix=/etc/nginx --sbin-path=/usr/sbin/nginx --with-http_ssl_module --with-http_v2_module --http-client-body-temp-path=/var/lib/nginx/tmp/client_body --http-proxy-temp-path=/var/lib/nginx/tmp/proxy --http-fastcgi-temp-path=/var/lib/nginx/tmp/fastcgi --pid-path=/var/run/nginx.pid --lock-path=/var/lock/subsys/nginx --add-module=../echo-nginx-module --add-module=../nginx_upstream_check_module --add-module=../ngx_log_if --add-module=../lua-nginx-module --with-ld-opt=-Wl,-rpath,/usr/local/lib --add-module=../headers-more-nginx-module --add-module=../nginx-goodies-nginx-sticky-module-ng --add-module=../srcache-nginx-module --add-module=../ngx_devel_kit

2.nginx配置文件server之前配置lua相关配置
lua_package_path "/data/AEDB/srv/nginx/conf/lua/?.lua;;";
lua_shared_dict primary_cache 200m;
lua_shared_dict secondary_cache 200m;
lua_shared_dict ngx_locks 1m;

3.日志输出接口请求返回值(与lua缓存功能无关)
body_filter_by_lua '
                local hwy_response_body = string.sub(ngx.arg[1], 1, 1000)
                ngx.ctx.buffered = (ngx.ctx.buffered or"") .. hwy_response_body
                if ngx.arg[2] then 
                        ngx.var.hwy_response_body = ngx.ctx.buffered
                end  
        ';   

4.调试方式
 location = /cache {
                internal;
                content_by_lua_file /data/AEDB/srv/nginx/conf/lua/hwy/cache.lua;
                proxy_redirect off; 
        }    

5.实例
location ~* /api/v1/bar{
                rewrite_by_lua_file /data/AEDB/srv/nginx/conf/lua/hwy/rewrite.lua;

                #srcache_fetch_skip $cache_skip;
                #srcache_store_skip $cache_skip;

                #srcache_fetch GET /cache key=$cache_key;
                #srcache_store PUT /cache key=$cache_key&exptime=$cache_expire;

                #add_header X-Cached-From $srcache_fetch_status;
                #add_header X-Cached-Store $srcache_store_status;
                #add_header X-md5-key $cache_key;

                add_header Access-Control-Allow-Origin *;
                add_header Access-Control-Allow-Headers X-Requested-With,hwy_rst;
                add_header Access-Control-Allow-Methods GET,POST,OPTIONS,PUT,DELETE,PATCH;

                proxy_set_header X-Real-IP $remote_addr;
                proxy_set_header Request_uri $request_uri;
                proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
                proxy_set_header Host $http_host;

                if ($remote_addr ~* "^(221.224.134.178)$") {
                        proxy_pass http://m_bar_nei;
                        break;
                }
                if ($proxy_add_x_forwarded_for ~* "221.224.134.178") {
                        proxy_pass http://m_bar_nei;
                        break;
                }

                proxy_pass http://m_bar_wai;
        }
		

说明：Lua目录结构
	hwy
	ngx
	resty