local request_method = ngx.var.request_method
local args = nil

if "GET" == request_method then
    args = ngx.req.get_uri_args()
elseif "POST" == request_method then
    ngx.req.read_body()
    args = ngx.req.get_post_args()
end
if args and type(args) =="table" then
    ngx.log(ngx.ERR, type(args))
    local t = {}
    for k, v in pairs(args) do
        table.insert(t, k.."="..v)
    end
    local temp = table.concat(t, "&")
    ngx.log(ngx.ERR, temp)
    ngx.var.hwy_req_args=temp
end
