---------------------------------------
--
-- 将接口返回数据保存至内存
-- Author：wangzheng
-- Version: 0.0.1
-- 
---------------------------------------
if ngx.req.get_headers()["x-skip"] == "TRUE" then
    return
end

local config, cache = require "hwy.config", require "hwy.cache"

local setmetatable = setmetatable
local method = ngx.req.get_method()

local _config = config:new()
local _cache = cache:new()

-- 计算缓存键
function getKey(uri, args)
    args = _config:pure(args)
    query = ngx.encode_args(args)

    local request_uri = query == "" and uri or uri .. "?" .. query
    return ngx.md5(request_uri)
end

-- 入口
do
    if method ~= "GET" then
        return
    end

    local args = ngx.req.get_uri_args()
    local api = nil
    if args and args["m"] then
        api = args["m"]
    end

    -- 匹配请求后，计算缓存键和缓存时间
    local uri = ngx.var.uri
    local rule = _config:check(uri, api)
    if rule then
        local cache_key = getKey(uri, args)
        _cache:set_expire(rule.expire)

        local val, err = _cache:get(cache_key)
        if not val then
            if err then ngx.log(ngx.ERR, err) end
            return
        end

        ngx.status = val.status
        ngx.print(val.body)
        return ngx.exit(val.status)
    end
    return
end
