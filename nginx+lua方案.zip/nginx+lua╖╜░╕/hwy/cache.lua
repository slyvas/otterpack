---------------------------------------
--
-- 将接口返回数据保存至内存，带二级缓存
-- 一级缓存，提高QPS
-- 二级缓存，防数据托底
-- Author：wangzheng
-- Version: 0.0.1
-- 
---------------------------------------

local resty_lock, cjson = require "resty.lock",  require "cjson"
local setmetatable = setmetatable

local method = ngx.req.get_method()
local lock_name = "ngx_locks"
local primary_cache = ngx.shared.primary_cache              -- 一级缓存，提高QPS
local secondary_cache = ngx.shared.secondary_cache          -- 二级缓存，防数据托底

local _M = { _VERSION = '0.0.1' }
local mt = { __index = _M }

function _M.new()
    local self = {
        primary_cache = primary_cache,
        secondary_cache = secondary_cache,
        expire = 60,
        x_cache_status = "MISS",
        no_cache = false
    }
    
    return setmetatable(self, mt)
end

-- 设置缓存时间
function _M.set_expire(self, expire)
    self.expire = tonumber(expire)
end

function _M.get(self, key)
    -- 从一级缓存取数据
    local val = self.primary_cache:get(key)
    if val then
        self.x_cache_status = "HIT"
        return self.wrapper(self, key, val)
    end

    -- 创建锁 
    local lock, err = resty_lock:new(lock_name)
    if not lock then
        return nil, "failed to create lock: " .. err
    end

    -- -- 没有获取锁
    local elapsed, err = lock:lock(key)
    if not elapsed then
        local val, err = self.secondary_cache:get(key)
        if val then
            return self.wrapper(self, key, val)
        end
        return nil,  err 
    end


    -- 成功得到锁!
    -- 有请求可能已经把值放到缓存中了, 所以我们在查询一遍
    val, err = self.primary_cache:get(key)
    if val then
        local ok, err = lock:unlock()
        if not ok then
            return nil, "failed to unlock: " .. err
        end

        self.x_cache_status = "HIT"
        return self.wrapper(self, key, val)
    end


    -- 二级缓存也没有，从后端取
    local val, err = self.fetch(self, key)
    if not val then
        local ok, err = lock:unlock()
        if not ok then
            return nil, "failed to unlock: " .. err
        end

        return nil, err 
    end

    ngx.log(ngx.ERR, self.no_cache)
    if self.no_cache then
        return val
    end

    -- 用新获取的值更新一级缓存 
    local ok, err = self.primary_cache:set(key, val, self.expire)
    if not ok then
        local ok, err = lock:unlock()
        if not ok then
            return nil, "failed to unlock: " .. err
        end

        return nil, "failed to update shm cache: " .. err 
    end

    local ok, err = lock:unlock()
    if not ok then
        return nil, "failed to unlock: " .. err
    end

    return self.wrapper(self, key, val)
end

function _M.fetch(self, key)
    -- 访问后端
    ngx.req.set_header("X-Skip", "TRUE")
    value = ngx.location.capture(ngx.var.request_uri)
    
    -- 后端响应正常，更新托底数据
    if value and value.status  == ngx.HTTP_OK and value.body then
        -- skip if Pragma is no-cache in response header
        if value.header and value.header['Pragma'] == 'no-cache' then
            self.no_cache = true
            ngx.log(ngx.ERR, 'no-cache')
            return value
        end

        local body = cjson.decode(value.body)
        if body.code and body.code == "0" then
            value = cjson.encode(value)
            local ok, err = self.secondary_cache:set(key, value, 86400)     -- 有效期24个小时
            if not ok then
                return nil, 'failed to set secondary_cache' .. err
            end
            return value
        end
    end

    ngx.log(ngx.ERR, "backend down")
    -- 后端响应不正常，获取托底数据
    local val, err = self.secondary_cache:get(key)
    if not val then
        return nil, 'failed get value from secondary_cache' 
    end
    self.x_cache_status = "HIT"
    return val
end

function _M.wrapper(self, key, val)
    local value = cjson.decode(val)
    for k,v in pairs(value.header) do
        ngx.header[k] = v
    end
    ngx.header["X-Cache-MD5"] = key
    ngx.header["X-Cache-Status"] = self.x_cache_status

    return value
end

return _M
