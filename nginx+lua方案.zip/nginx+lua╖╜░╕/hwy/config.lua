-----------------------------------------------
-- 
-- 缓存配置
-- Author：wangzheng
-- Version：0.0.1
--
-----------------------------------------------

local setmetatable = setmetatable

local _M = { _VERSION = '0.01' }
local mt = { __index = _M }

local config = {
    rules = {
        {uri = "/api/v1/bar/thread.json", api = "bar_app", expire = 10},
        {uri = "/api/v1/bar/thread/search.json", api = "bar_app", expire = 30},
        {uri = "/api/v1/bar/thread/info.json", api = "info", expire = 10},
        {uri = "/gf/m/activity/illustration/getWorksInfo.do", expire = 1},
       


    },
    dirty_args = {
        "sign",     "vtime",      "uuid", 
        "token",    "model",      "mac",      "os"
    }
}

function _M:new()
    local self = {
        memcached = config.memcached,
        rules = config.rules,
    }

    return setmetatable(self, mt)
end

-- 校验接口
function _M:check(uri, api)
    for _, v in ipairs(config.rules) do    
        if v.uri == uri then     
            if api == nil then
                return v
            elseif v.api and v.api == api then
                return v
            end
        end
    end
    return nil
end

-- 去除可变传参，生成比较干净的传参
function _M:pure(args)
    for _, v in ipairs(config.dirty_args) do
        if args and args[v] then
            args[v] = nil
        end
    end

    return args
end

return _M
