local utf8 = require 'lua-utf8'

local ENCKEY = 'D7f3y1Ef@U46Q2u8^Fy2M'
local len_key = string.len(ENCKEY)

local function decrypt(str)
    local out, j = "", 1
    local len_str = utf8.len(str)

    for i = 1, len_str do
        if j > len_key then
            j = j % len_key
        end

        local ch = utf8.byte(str, i) + 65535 - string.byte(ENCKEY, j)

        if ch > 65535 then
            ch = ch % 65535
        end

        local tar = utf8.char(ch)
        if tar == "|" then
            break
        end

        out = out .. tar
        j = j + 1
    end

    return out
end


local request_method = ngx.var.request_method
local args = nil

if "GET" == request_method then
    args = ngx.req.get_uri_args()
elseif "POST" == request_method then
    ngx.req.read_body()
    args = ngx.req.get_post_args()
end

if args and args["c"] then
	local status, ret = pcall(decrypt, args["c"])
	if status then
		ngx.var.hwy_api = ret
                ngx.log(ngx.ERR, "hwy_api: ", ret)
	else
		ngx.var.hwy_api = args["c"]
	end
end
