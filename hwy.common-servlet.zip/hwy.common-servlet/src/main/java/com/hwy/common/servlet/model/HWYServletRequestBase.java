package com.hwy.common.servlet.model;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import com.hwy.common.data.BaseDao;
import com.hwy.common.exception.ErrorCodeBase;
import com.hwy.common.exception.ExceptionCommonBase;
import com.hwy.common.logging.Logger;
import com.hwy.common.servlet.util.WebUtils;
import com.hwy.common.util.Utils;

public class HWYServletRequestBase implements IHWYServletRequest {

	private static Logger logger = Logger.getLogger(HWYServletRequestBase.class);

	private static final String sclazz = "com.hwy.common.servlet.model.HWYServletRequestBase";
	private static Class clazz = null;
	private Object cacheObject=null;

	public Object getCacheObject() {
        return cacheObject;
    }
	
    public void setCacheObject(Object cache) {
        this.cacheObject=cache;
    }

    public static void setClazz(String className) throws ExceptionCommonBase {
		if (Utils.stringIsNullOrEmpty(className))
			className = sclazz;
		try {
			clazz = Class.forName(className);
		} catch (ClassNotFoundException e) {
			throw new ExceptionCommonBase(ErrorCodeBase.SysConfigError, e);
		}

	}

	public static HWYServletRequestBase get(HttpServletRequest req) throws ExceptionCommonBase {

		try {
			HWYServletRequestBase obj = (HWYServletRequestBase) clazz.newInstance();
			obj.req = req;
			return obj;
		} catch (InstantiationException | IllegalAccessException e) {
			throw new ExceptionCommonBase(ErrorCodeBase.SysConfigError, e);
		}
	}

	public HWYServletRequestBase() {

	}

	public HWYServletRequestBase(HttpServletRequest req) {
		this.req = req;
	}

	private HttpServletRequest req = null;

	public final HttpServletRequest getRequest() {
		return req;
	}

	protected long userId = 0L;

	public long getUId() throws ExceptionCommonBase {
		return userId;
	}

	public final boolean isLogin() {
		try {
			return getUId() > 0;
		} catch (Exception ex) {
			return false;
		}
	}

	public final int getInt(String paramName, int defaultValue) {
		return WebUtils.getInt(req, paramName, defaultValue);
	}

	public final long getLong(String paramName, long defaultValue) {
		return WebUtils.getLong(req, paramName, defaultValue);
	}

	public final String getString(String paramName) {
		return WebUtils.getString(req, paramName);
	}

	public final String getString(String paramName, String defaultValue) {
		return WebUtils.getString(req, paramName, defaultValue);
	}


}
