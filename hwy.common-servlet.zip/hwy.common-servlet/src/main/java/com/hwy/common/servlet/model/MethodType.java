package com.hwy.common.servlet.model;

import java.io.Serializable;
import java.util.TreeMap;

public enum MethodType implements Serializable {
	get(1), post(2), put(3), delete(4);
	int _value = 0;

	private static TreeMap<Integer, MethodType> _map;

	static {
		_map = new TreeMap<Integer, MethodType>();
		for (MethodType num : MethodType.values()) {
			_map.put(new Integer(num.value()), num);
		}
	}

	public static MethodType lookup(int value) {
		return _map.get(new Integer(value));
	}

	MethodType(int value) {
		this._value = value;
	}

	public int value() {
		return this._value;
	}
}
