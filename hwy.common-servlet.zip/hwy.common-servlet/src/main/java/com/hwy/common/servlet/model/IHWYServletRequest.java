package com.hwy.common.servlet.model;

import javax.servlet.http.HttpServletRequest;

import com.hwy.common.exception.ExceptionCommonBase;

public interface IHWYServletRequest {
	public HttpServletRequest getRequest();

	public long getUId() throws ExceptionCommonBase;
}
