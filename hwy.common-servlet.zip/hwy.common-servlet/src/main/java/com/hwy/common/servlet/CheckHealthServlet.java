package com.hwy.common.servlet;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.hwy.common.logging.Logger;
import com.hwy.common.servlet.model.MethodType;
import com.hwy.common.util.Utils;

public class CheckHealthServlet extends HttpServlet {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private static final Logger log = Logger.getLogger(CheckHealthServlet.class);
	
	private static final String FILE_VERSION = "version.txt";
	private static final String FILE_HISTORY = "history.txt";

	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		processRequest(req, resp, MethodType.get);
	}

	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		processRequest(req, resp, MethodType.post);
	}

	private void processRequest(HttpServletRequest req, HttpServletResponse resp, MethodType get) throws IOException {
		try {
			if(null != req.getParameter("version")){
				version(req, resp, get);
				return;
			}
			int more = Utils.toInt(req.getParameter("more"), 0);
			if (more > 0) {
				resp.getOutputStream().print(1);
			} else {
				resp.getOutputStream().print(1);
			}
		} catch (

		IOException ex) {
			try {
				resp.getOutputStream().print(0);
			} catch (IOException e) {
			}
			log.error(ex);
		}
	}
	
	private void version(HttpServletRequest req, HttpServletResponse resp, MethodType get) throws IOException{
		resp.setHeader("Content-type", "text/plain;charset=UTF-8");
		resp.setCharacterEncoding("UTF-8");
		String path = req.getSession().getServletContext().getRealPath("/");
		StringBuilder sbf = new StringBuilder();
		String version = readFile(path + File.separator + FILE_VERSION);
		String history = readFile(path + File.separator + FILE_HISTORY);
		sbf.append("version info:\n").append(version).append("\nhistory info:\n").append(history);
		PrintWriter writer = resp.getWriter();
		writer.print(sbf.toString());
		writer.flush();
		writer.close();
	}
	
	private String readFile(String file) throws IOException{
		File f = new File(file);
		if(f.exists()){
			byte[] content = Utils.fileToBytes(file);
			String c = new String(content, "UTF-8");
			return c;
		}
		return "";
	}
}
