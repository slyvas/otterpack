package com.hwy.common.servlet.handler;

import javax.servlet.http.HttpServletRequest;

import com.hwy.common.servlet.util.WebUtils;

public abstract class BaseHandler {

	public BaseHandler() {
		init();
	}
	
    protected String cache = "page";
	protected abstract void init();

	public static int getInt(HttpServletRequest req, String paramName, int defaultValue) {
		return WebUtils.getInt(req, paramName, defaultValue);
	}

	public static long getLong(HttpServletRequest req, String paramName, long defaultValue) {
		return WebUtils.getLong(req, paramName, defaultValue);
	}

	public static String getString(HttpServletRequest req, String paramName) {
		return WebUtils.getString(req, paramName);
	}

	public static String getString(HttpServletRequest req, String paramName, String defaultValue) {
		return WebUtils.getString(req, paramName, defaultValue);
	}

}
