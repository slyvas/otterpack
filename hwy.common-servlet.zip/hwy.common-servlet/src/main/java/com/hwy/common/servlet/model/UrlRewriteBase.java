package com.hwy.common.servlet.model;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

import javax.servlet.http.HttpServletRequest;

import com.hwy.common.exception.ExceptionCommonBase;
import com.hwy.common.servlet.util.WebUtils;
import com.hwy.common.util.Utils;

public abstract class UrlRewriteBase {
    private Pattern pattern;
    private Method method;
    private int cache_time = 60;
    private boolean cache_handler = false;
    private boolean cache_switch = false;
    private boolean check_login = false;
    private List<String> keys = new ArrayList<String>();
    private boolean loginUserKey = false;
    private Pattern patternCache;

    public void setKeys(String key) {
        if (key.startsWith("login_user_id")) {
            loginUserKey = true;
            key = key.replace("login_user_id", "");
        }
        this.keys = Utils.toListString(key);
    }

    public boolean needCache(HWYServletRequestBase req) {
        if (!cache_switch)
            return false;
        String m = req.getString("m");
        return m == null || Utils.stringCompare(m, "home") || Utils.stringCompare(m, "prime");
    }

    public String toKey(HWYServletRequestBase req) throws ExceptionCommonBase {
        String str = "";
        if (loginUserKey) {
            str += "login_user_id=" + req.getUId() + "&";
        }

        for (String s : keys) {
            str += s + "=" + req.getString(s) + "&";
        }

        if (Utils.stringIsNullOrEmpty(str))
            str = req.getRequest().getQueryString();

        return str;
    }

    public boolean isCheck_login() {
        return check_login;
    }

    public void setCheck_login(boolean check_login) {
        this.check_login = check_login;
    }

    public boolean getCache_switch() {
        return cache_switch && cache_time > 0;
    }

    public void setCache_switch(boolean cache_switch) {
        this.cache_switch = cache_switch;
    }

    public int getCache_time() {
        return cache_time;
    }

    /**
     * @param sec
     */
    public void setCache_time(int sec) {
        this.cache_time = sec;
        this.cache_handler = sec % 10 == 1;
    }

    public boolean isCache_handler() {
        return cache_handler;
    }

    public Pattern getPattern() {
        return pattern;
    }

    public void setPattern(Pattern pattern) {
        this.pattern = pattern;
    }

    public Method getMethod() {
        return method;
    }

    public void setMethod(Method method) {
        this.method = method;
    }
}
