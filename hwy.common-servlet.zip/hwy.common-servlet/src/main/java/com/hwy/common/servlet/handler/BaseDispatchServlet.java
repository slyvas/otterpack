package com.hwy.common.servlet.handler;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Properties;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import com.hwy.common.config.ConfigProvider;
import com.hwy.common.exception.ErrorCodeBase;
import com.hwy.common.exception.ExceptionCommonBase;
import com.hwy.common.servlet.model.HWYServletRequestBase;
import com.hwy.common.servlet.model.MethodType;
import com.hwy.common.servlet.model.ResultObject;
import com.hwy.common.servlet.util.WebUtils;
import com.hwy.common.util.Utils;

public class BaseDispatchServlet extends HttpServlet {

	private static final long serialVersionUID = 1L;
	protected Logger log = Logger.getLogger(this.getClass());
	private static final String encoding_utf8 = "utf-8";
	private static final String contentType_json = "application/json";
	private static final String contentType_text = "text/plain;charset=utf-8";
	private static final String compare_json = ".json";
	private static final String header_access_control = "Access-Control-Allow-Origin";
	private String signKey = null;

	private Properties msgProperties = new Properties();

	@Override
	public void init() {
		signKey = getInitParameter("signKey");
		String webRoot = getServletContext().getRealPath("/WEB-INF");
		Utils.setAppRoot(webRoot);
		Utils.initLog4j();
		ConfigProvider.getInstance().init();
		try {
			String clazz = ConfigProvider.getInstance().getValue("service.open.biz.servlet_class_name");
			if (Utils.stringIsNullOrEmpty(clazz)) {
				log.error("service.open.biz.servlet_class_name=default");
			}

			HWYServletRequestBase.setClazz(clazz);

		} catch (ExceptionCommonBase e) {
			log.error(null, e);
		}
		// TODO:提示信息
		/*
		 * try { msgProperties = Utils.getProperties("i18n/"); } catch
		 * (FileNotFoundException e) { log.error(null, e); }
		 */
	}

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		processRequest(req, resp, MethodType.get);
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		processRequest(req, resp, MethodType.post);
	}

	@Override
	protected void doPut(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		processRequest(req, resp, MethodType.put);
	}

	@Override
	protected void doDelete(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		processRequest(req, resp, MethodType.delete);
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	private void processRequest(HttpServletRequest req, HttpServletResponse resp, MethodType method)
			throws IOException, ServletException {
		ResultObject result = new ResultObject();
		Object obj = null;
		String ext = null;
		try {
			ext = Utils.getFileExtName(req.getRequestURI());

			resp.setCharacterEncoding(encoding_utf8);
			if (Utils.stringCompare(ext, compare_json))
				resp.setContentType(contentType_json);
			else
				resp.setContentType(contentType_text);

			if (log.isInfoEnabled())
				log.info(req.getMethod() + " " + req.getRequestURL() + "?" + WebUtils.getRequestAllParameter(req));

			checkParam(req);

			obj = OpenHandler.getInstance().handler(req, resp, method, ext);

			/*
			 * if (obj == null) obj = new Object();
			 */

		} catch (ExceptionCommonBase e) {
			if (e.getErrorCode() == ErrorCodeBase.ExceptionIgnoreError)
				return;
			log.error(null, e);
			result.setCode(e.getErrorCode() + "");
			result.setMsg(e.getMessage());
		} catch (Throwable e) {
			log.error(null, e);
			try {
				throw ExceptionCommonBase.throwExceptionCommonBase(e);
			} catch (ExceptionCommonBase ex) {
				result.setCode(ex.getErrorCode() + "");
				result.setMsg(e.getMessage());
			} catch (Throwable ex) {
				result.setCode(
						String.valueOf(ExceptionCommonBase.parseErrorCode(e, ErrorCodeBase.UnDefinedServerError)));
				result.setMsg(ex.getMessage());
			}
		} finally {
			if (obj instanceof ResultObject)
				result = (ResultObject) obj;
			else
				result.setObj(obj);
		}

		if (!"0".equals(result.getCode()) && Utils.stringIsNullOrEmpty(result.getMsg()))
			result.setMsg(getErrorMessage(result.getCode(), result.getObj()));

		byte[] json = WebUtils.toJSonBytes(result);
		if (json == null)
			json = ("{\"code\":" + ErrorCodeBase.UnDefinedServerError + ",\"msg\":\"\", \"obj\":null}").getBytes();

		PrintWriter writer = null;
		try {
			resp.setContentLength(json.length);
			resp.getOutputStream().write(json);
			resp.getOutputStream().flush();

			if (WebUtils.getInt(req, "debug", 0) > 0) {
				log.info("[" + req.getMethod() + "] " + req.getRequestURI() + "?" + WebUtils.getRequestAllParameter(req)
						+ "\r\n" + json);
			}
		} catch (Exception e) {
			log.error("resultOutput error", e);
		} finally {
			if (writer != null) {
				writer.close();
			}
		}
	}

	private void checkParam(HttpServletRequest req) throws ExceptionCommonBase {
		if ((Utils.stringIsNullOrEmpty(signKey) || "1".equals(WebUtils.getString(req, "skip")))) {
			return;
		} else {
			if (!WebUtils.checkSign(req, "sign", signKey))
				throw new ExceptionCommonBase(ErrorCodeBase.ParameterError);
		}
	}

	private String getErrorMessage(String errorCode, Object objs) {
		Object[] objArr = null;
		String msg = null;
		try {
			if (errorCode == null)
				errorCode = ErrorCodeBase.UnDefinedServerError + "";

			if (objs != null) {
				if (objs instanceof String)
					objArr = new Object[] { (String) objs };
				else if (objs instanceof Object[])
					objArr = (Object[]) objs;
				else
					objArr = new Object[] { objs };
			}
		} catch (Exception e) {
			errorCode = ErrorCodeBase.UnDefinedServerError + "";
		}

		int code = Utils.toInt(errorCode, 0);
		if (code != 0 && msgProperties != null) {
			msg = msgProperties.getProperty(code > 0 ? errorCode : ErrorCodeBase.getLangString(code));
			if (!Utils.stringIsNullOrEmpty(msg) && null != objArr) {
				try {
					msg = String.format(msg, objArr);
				} catch (Exception e) {
					log.error("", e);
				}
			}
		}

		return msg;
	}

}
