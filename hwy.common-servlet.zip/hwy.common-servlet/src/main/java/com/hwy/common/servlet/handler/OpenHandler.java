package com.hwy.common.servlet.handler;

import com.hwy.common.exception.ExceptionCommonBase;
import com.hwy.common.logging.Logger;
import com.hwy.common.util.Utils;

public class OpenHandler extends ServletHandlerBase {
	static {
		Utils.initLog4j();
	}

	static Logger logger = Logger.getLogger("OpenHandler");
	static byte[] SyncRoot = new byte[0];
	private static OpenHandler instance = null;

	public OpenHandler(String config) throws ExceptionCommonBase {
		super(config);
	}

	public static OpenHandler getInstance() throws ExceptionCommonBase {
		if (instance == null)
			synchronized (SyncRoot) {
				instance = new OpenHandler("url_rewrite.properties");
			}
		return instance;
	}

	@Override
	protected void init() {
		// TODO Auto-generated method stub
	}

}
