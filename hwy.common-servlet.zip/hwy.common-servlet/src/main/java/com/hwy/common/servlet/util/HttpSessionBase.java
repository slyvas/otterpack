package com.hwy.common.servlet.util;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.hwy.common.exception.ExceptionCommonBase;
import com.hwy.common.logging.Logger;
import com.hwy.common.servlet.model.SessionBase;


public abstract class HttpSessionBase {
	private static Logger logger = Logger.getLogger(HttpSessionBase.class
			.getSimpleName());
	protected final static int INT_MaxInactiveIntervalMinuter = 30;
	protected final static String STR_SESSION = "D_SESSION";

	public abstract void cookieRemove(HttpServletResponse resp)
			throws ExceptionCommonBase;

	public abstract void cookieSet(HttpServletResponse resp, SessionBase session)
			throws ExceptionCommonBase;

	public SessionBase getSession(HttpServletRequest req,
			HttpServletResponse resp) throws ExceptionCommonBase {
		return this.getSession(req, resp, false);
	}

	public SessionBase getSessionIgnoreError(HttpServletRequest req,
			HttpServletResponse resp) throws ExceptionCommonBase {
		return this.getSessionIgnoreError(req, resp, false);
	}

	public SessionBase getSessionIgnoreError(HttpServletRequest req,
			HttpServletResponse resp, boolean overwrite)
			throws ExceptionCommonBase {
		SessionBase session = null;
		try {
			return this.getSession(req, resp, overwrite);
		} catch (Exception ex) {
			logger.error(ex);
		}
		if (session == null)
			session = sessionInit();
		return session;
	}

	public SessionBase getSession(HttpServletRequest req,
			HttpServletResponse resp, boolean overwrite)
			throws ExceptionCommonBase {
		SessionBase session = null;
		try {
			HttpSession hs = req.getSession();
			if (hs != null) {

				Object obj = hs.getAttribute(STR_SESSION);
				if (obj != null && obj instanceof SessionBase) {
					session = (SessionBase) obj;
					return session;
				}
			}

			if (session == null || (overwrite && !session.isLogin())) {
				session = sessionFromOther(req);
			}

			sessionSet(req, resp, session);
		} catch (Exception ex) {
			logger.error(ex);
		}
		if (session == null)
			session = sessionInit();
		return session;
	}

	public void seesionRemove(HttpServletRequest req, HttpServletResponse resp)
			throws ExceptionCommonBase {
		HttpSession hs = req.getSession();
		if (hs != null) {
			hs.removeAttribute(STR_SESSION);
			cookieRemove(resp);
		}
	}

	public abstract SessionBase sessionFromOther(HttpServletRequest req)
			throws ExceptionCommonBase;

	public abstract SessionBase sessionInit() throws ExceptionCommonBase;

	public void sessionSet(HttpServletRequest req, HttpServletResponse resp,
			SessionBase session) throws ExceptionCommonBase {
		HttpSession hs = req.getSession();
		if (session != null) {
			if (hs.getAttribute(STR_SESSION) != null) {
				hs.removeAttribute(STR_SESSION);
			}
			hs.setAttribute(STR_SESSION, session);
			hs.setMaxInactiveInterval(INT_MaxInactiveIntervalMinuter * 60);
			cookieSet(resp, session);
		}
	}
}
