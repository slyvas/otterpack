package com.hwy.common.servlet.handler;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.hwy.common.cache.ICacheClient;
import com.hwy.common.cache.SCacheClient;
import com.hwy.common.exception.ErrorCodeBase;
import com.hwy.common.exception.ExceptionCommonBase;
import com.hwy.common.logging.Logger;
import com.hwy.common.servlet.model.HWYServletRequestBase;
import com.hwy.common.servlet.model.MethodType;
import com.hwy.common.servlet.model.UrlRewriteBase;
import com.hwy.common.util.Utils;

public abstract class ServletHandlerBase extends BaseHandler {

	class UrlRewrite extends UrlRewriteBase {
	}

	protected Logger logger = Logger.getLogger(ServletHandlerBase.class.getSimpleName());
	protected List<UrlRewriteBase> mapping = new ArrayList<UrlRewriteBase>();

	public ICacheClient getCache() {
		return SCacheClient.getInstance(cache + ".open");
	}

	private static final Pattern regex_version = Pattern.compile("version=([0-9]*)[　 ]*cache_name=([a-zA-Z0-9]*)");

	public ServletHandlerBase(String config) throws ExceptionCommonBase {
		List<UrlRewriteBase> temp = new ArrayList<UrlRewriteBase>();
		try {
			String file = Utils.getConfigFile(config);
			File f = new File(file);
			InputStreamReader insReader = new InputStreamReader(new FileInputStream(f), "UTF-8");
			BufferedReader in = new BufferedReader(insReader);
			String line = null;
			int version = -1;
			while ((line = in.readLine()) != null) {
				// (get|post)

				// /api/v1/user/password.json=cn.egame.server.open.biz.factory.UserHandler:updatePassWord:1:60
				if (line.startsWith("#") && version < 0) {
					Matcher m = regex_version.matcher(line);
					if (m.find()) {
						version = Utils.toInt(m.group(1), 0);
						if (m.groupCount() > 1) {
							this.cache = m.group(2);
						}
						if (version <= 0)
							logger.error("error version=0 (" + line + ")");
					} else
						version = 0;

				}

				if (!Utils.stringIsNullOrEmpty(line) && !line.startsWith("#")) {
					String[] s = line.split("=");
					if (s == null || s.length != 2)
						throw new ExceptionCommonBase(ErrorCodeBase.SysConfigError, line + " is error(=).");

					UrlRewrite item = new UrlRewrite();
					item.setPattern(Pattern.compile(s[0]));
					String[] cm = s[1].split(":");
					if (cm == null || cm.length < 2)
						throw new ExceptionCommonBase(ErrorCodeBase.SysConfigError, line + " is error(:).");

					Class clazz = Class.forName(cm[0]);
					Method[] methods = clazz.getMethods();
					for (Method m : methods) {
						if (Utils.stringCompare(m.getName(), cm[1])) {
							item.setMethod(m);
							temp.add(item);
							break;
						}
					}

					switch (version) {
					case 1:
						// (get)
						// /api/v1/user/update_info.json=v1.user..UserHandler:setUserData
						// 1 1 60 m{(home|prime)},s
						if (cm.length == 3)
							item.setCheck_login(Utils.toInt(cm[2], 0) > 0);
						else if (cm.length == 6) {
							if (cm.length > 3)
								item.setCache_switch(Utils.toInt(cm[3], 0) > 0);
							if (cm.length > 4)
								item.setCache_time(Utils.toInt(cm[4], 0));
							if (cm.length > 5)
								item.setKeys(cm[5]);
						} else if (cm.length != 2)
							throw new ExceptionCommonBase(ErrorCodeBase.SysConfigError, line + " is error.");
						break;
					default:
						if (cm.length > 2)
							item.setCache_switch(Utils.toInt(cm[2], 0) > 0);
						if (cm.length > 3)
							item.setCache_time(Utils.toInt(cm[3], 0));
						if (cm.length > 4)
							item.setCheck_login(Utils.toInt(cm[4], 0) > 0);
						break;
					}
					if (item.getMethod() == null)
						throw new ExceptionCommonBase(ErrorCodeBase.SysConfigError, line + " is error.");
				}
			}

			mapping = temp;
		} catch (UnsupportedEncodingException e) {
			logger.error(null, e);
		} catch (IOException e) {
			throw new ExceptionCommonBase(ErrorCodeBase.SysConfigError, e);
		} catch (ClassNotFoundException e) {
			throw new ExceptionCommonBase(ErrorCodeBase.SysConfigError, e);
		}

	}

	public Object handler(HttpServletRequest req, HttpServletResponse resp, MethodType method, String ext)
			throws ExceptionCommonBase {

		try {
			boolean is_run = false;
			String url = req.getRequestURI();
			if (ext == null)
				ext = Utils.getFileExtName(url);

			String[] paths = null;
			String u = null;
			if (!Utils.stringIsNullOrEmpty(url)) {
				while (url.indexOf("//") > 0) {
					url = url.replaceAll("//", "/");
				}

				u = method.name() + " " + url;

				while (url.startsWith("/")) {
					url = url.substring(1);
				}

				if (url.endsWith(ext)) {
					url = url.substring(0, url.length() - ext.length());
				}

				paths = url.toLowerCase().split("/");
			} else
				u = method.name() + " /";

			Object result = null;
			for (UrlRewriteBase item : mapping) {
				Matcher m = item.getPattern().matcher(u);
				if (m.find()) {
					String key = null;
					is_run = true;
					HWYServletRequestBase r = HWYServletRequestBase.get(req);
					if (item.isCheck_login() && (r.getUId() < 1))
						throw new ExceptionCommonBase(ErrorCodeBase.ExceptionUserNotLogin);

					boolean needCache = cache != null && item.needCache(r);
					boolean cache_hit = false;
					if ((MethodType.get.value() == method.value()) && needCache && r.getInt("debug", 0) < 1) {
						key = req.getRequestURI() + "?" + item.toKey(r);
						if (key.length() > 256) {
							key = Utils.encryptMD5(key);
						}
						Object obj = getCache().getT(Object.class, key);
						if (obj != null) {
							logger.info("page cache hit ,key:" + key);
							cache_hit = true;
							if (!item.isCache_handler())
								return obj;
							else {
								r.setCacheObject(Utils.clone(obj));
							}
						}
					}
					result = item.getMethod().invoke(null, new Object[] { r, resp, method, paths, ext });

					if (needCache && !cache_hit) {
						logger.info("page cache set key:" + key);
						getCache().set(key, result, item.getCache_time());
					}

					return result;
				}
			}

			if (!is_run)
				throw new ExceptionCommonBase(ErrorCodeBase.SysConfigError,
						"url_write(" + u + ") is out of the config.");

		} catch (Exception e) {
			if (e.getCause() != null) {
				logger.error(null, e);
				throw ExceptionCommonBase.throwExceptionCommonBase(e.getCause());
			} else
				throw ExceptionCommonBase.throwExceptionCommonBase(e);
		} finally {
		}
		return null;
	}
}
