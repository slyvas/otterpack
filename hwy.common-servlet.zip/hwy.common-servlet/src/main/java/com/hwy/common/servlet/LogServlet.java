package com.hwy.common.servlet;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.hwy.common.util.Utils;
import com.hwy.common.logging.Logger;
import com.hwy.common.operation.ICheckHealth;
import com.hwy.common.servlet.model.MethodType;

public class LogServlet extends HttpServlet {

	private static final long serialVersionUID = 6088562460296534968L;
	private static final Logger log = Logger.getLogger(LogServlet.class);
	public List<ICheckHealth> checks = new ArrayList<ICheckHealth>();

	@Override
	public void init() throws ServletException {
		String webRoot = this.getServletContext().getRealPath("/WEB-INF");
		Utils.setAppRoot(webRoot);
		log.info("LogServlet start successfully .........");
	}

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		processRequest(req, resp, MethodType.get);
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		processRequest(req, resp, MethodType.post);
	}

	private void processRequest(HttpServletRequest req,
			HttpServletResponse resp, MethodType get) {
		try {
			resp.getOutputStream().print("{\"code\":1}");

		} catch (IOException ex) {
			try {
				resp.getOutputStream().print("{\"code\":0}");
			} catch (IOException e) {
			}
			log.error(ex);
		}
	}
}
