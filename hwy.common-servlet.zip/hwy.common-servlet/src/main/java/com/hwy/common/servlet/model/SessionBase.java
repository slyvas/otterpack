package com.hwy.common.servlet.model;

public class SessionBase {
	public boolean isLogin() {
		return loginUserId > 0;
	}

	public int getAppId() {
		return appId;
	}

	public void setAppId(int appId) {
		this.appId = appId;
	}

	public long getLoginUserId() {
		return loginUserId;
	}

	public void setLoginUserId(long loginUserId) {
		this.loginUserId = loginUserId;
	}

	private int appId;
	private long loginUserId;
	private Object clientData;
	public Object getClientData() {
		return clientData;
	}

	public void setClientData(Object clientData) {
		this.clientData = clientData;
	}
}
