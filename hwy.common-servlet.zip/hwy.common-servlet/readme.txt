1.tomcat check	 
	
	<servlet>
		<servlet-name>CheckHealth</servlet-name>
		<servlet-class>com.hwy.common.servlet.CheckHealthServlet</servlet-class>
		<load-on-startup>0</load-on-startup>
	</servlet>
	<servlet-mapping>
		<servlet-name>CheckHealth</servlet-name>
		<url-pattern>/health.json</url-pattern>
	</servlet-mapping>
	
2.filter
	<filter>
		<filter-name>FilterEncodeUtils</filter-name>
		<filter-class>com.hwy.common.servlet.util.FilterEncodeUtils</filter-class>
		<init-param>
			<param-name>encoding</param-name>
			<param-value>utf-8</param-value>
		</init-param>
	</filter>

	<filter-mapping>
		<filter-name>FilterEncodeUtils</filter-name>
		<url-pattern>/*</url-pattern>
	</filter-mapping>